class Result:
    pass
